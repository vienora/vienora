import SupplierDashboard from '@/components/SupplierDashboard';

export default function SuppliersAdminPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <SupplierDashboard />
    </div>
  );
}
