# Vienora Integration Documentation

This folder contains integration guides and project documentation.

## Key Files
- `PRINTFUL_INTEGRATION_GUIDE.md` - Step-by-step Printful API setup
- `INVENTORY_VOLUME_ANALYSIS.md` - Expected product catalog projections
- `todos.md` - Current project priorities and tasks
