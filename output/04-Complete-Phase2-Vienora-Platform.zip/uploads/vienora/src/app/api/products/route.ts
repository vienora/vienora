import { NextRequest, NextResponse } from 'next/server';
import { printfulSync } from '@/lib/printful-sync';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const source = searchParams.get('source') || 'auto';
    const category = searchParams.get('category');
    const limit = parseInt(searchParams.get('limit') || '20');

    console.log('📦 Product API called with source:', source);

    let products = [];
    let actualSource = 'demo';
    let message = 'Demo products loaded';

    if (source === 'printful' || source === 'auto') {
      try {
        // Try to get real Printful products
        console.log('🔄 Fetching real Printful products...');
        const printfulProducts = await printfulSync.fetchAndTransformProducts(limit);

        if (printfulProducts.length > 0) {
          products = printfulProducts;
          actualSource = 'printful';
          message = 'Real Printful products loaded successfully';

          // Filter by category if requested
          if (category) {
            products = products.filter(product =>
              product.category.toLowerCase().includes(category.toLowerCase())
            );
          }

          console.log(`✅ Using ${products.length} real Printful products`);

          return NextResponse.json({
            success: true,
            source: actualSource,
            products: products.slice(0, limit),
            total: products.length,
            message,
            filters: {
              category,
              limit
            }
          });
        }
      } catch (error) {
        console.error('❌ Printful API error:', error);
      }
    }

    // If we get here, either Printful failed or wasn't requested
    // Return a clear message about what happened
    const fallbackMessage = source === 'printful'
      ? 'Printful API not configured - add PRINTFUL_API_KEY to environment variables'
      : 'Demo products loaded (configure Printful API for real products)';

    return NextResponse.json({
      success: true,
      source: 'demo',
      products: [],
      total: 0,
      message: fallbackMessage,
      setup: {
        required: 'PRINTFUL_API_KEY environment variable',
        docs: 'See .same/PRINTFUL_INTEGRATION_GUIDE.md for setup instructions'
      }
    });

  } catch (error) {
    console.error('❌ Product API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to load products',
        message: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
