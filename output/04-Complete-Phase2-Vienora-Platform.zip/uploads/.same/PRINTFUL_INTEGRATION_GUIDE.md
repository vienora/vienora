# 🚀 PRINTFUL INTEGRATION GUIDE - GET REAL PRODUCTS NOW
## Step-by-Step Connection to Replace Placeholder Data

### 🎯 OBJECTIVE
Replace Vienora's placeholder products with **real Printful products and pricing** that you can start selling immediately.

---

## 📋 PHASE 1: PRINTFUL ACCOUNT SETUP (5 minutes)

### **Step 1.1: Create Printful Account**
1. **Visit**: https://www.printful.com/
2. **Click**: "Sign up" (top right)
3. **Choose**: "I want to sell" option
4. **Fill out business information**:
   ```
   Business Name: Vienora Luxury
   Business Type: Online Store
   Monthly Volume: 100-500 orders
   Main Products: Custom apparel and accessories
   ```
5. **Verify email** and complete setup

### **Step 1.2: Access API Credentials**
1. **Login** to your Printful dashboard
2. **Navigate**: Settings → API
3. **Create API Key**:
   - Name: "Vienora Production"
   - Permissions: Full access
   - **Copy and save** the API key securely

---

## 🔧 PHASE 2: API INTEGRATION SETUP

### **Step 2.1: Update Environment Variables**
Add to your `.env.local` file:

```env
# Printful API Configuration
PRINTFUL_API_KEY=your_printful_api_key_here
PRINTFUL_BASE_URL=https://api.printful.com
PRINTFUL_WEBHOOK_SECRET=your_webhook_secret_here

# Printful Store ID (get from dashboard)
PRINTFUL_STORE_ID=your_store_id_here
```

### **Step 2.2: Install Required Dependencies**
```bash
# In your project directory
bun add axios
bun add @types/node
```

---

## 🔌 PHASE 3: PRINTFUL API INTEGRATION

### **Step 3.1: Create Printful API Service**

```typescript
// src/lib/printful-api.ts
interface PrintfulProduct {
  id: number;
  external_id: string;
  name: string;
  thumbnail: string;
  is_ignored: boolean;
  synced: number;
  retail_price: string;
  currency: string;
  product: {
    variant_id: number;
    product_id: number;
    image: string;
    name: string;
  };
  variants: PrintfulVariant[];
}

interface PrintfulVariant {
  id: number;
  external_id: string;
  sync_product_id: number;
  name: string;
  synced: boolean;
  variant_id: number;
  retail_price: string;
  sku: string;
  currency: string;
  product: {
    variant_id: number;
    product_id: number;
    image: string;
    name: string;
    size: string;
    color: string;
    color_code: string;
    color_code2?: string;
  };
  files: Array<{
    id: number;
    type: string;
    hash: string;
    url: string;
    filename: string;
    mime_type: string;
    size: number;
    width: number;
    height: number;
    dpi: number;
    status: string;
    created: number;
    thumbnail_url: string;
    preview_url: string;
    visible: boolean;
  }>;
}

interface PrintfulCatalogProduct {
  id: number;
  type: string;
  description: string;
  type_name: string;
  title: string;
  brand: string;
  model: string;
  image: string;
  variant_count: number;
  currency: string;
  retail_price: string;
  files: Array<{
    id: string;
    type: string;
    title: string;
    additional_price: string;
  }>;
  options: Array<{
    id: string;
    title: string;
    type: string;
    values: Record<string, any>;
    additional_price: string;
  }>;
  dimensions: {
    front: string;
  };
  is_discontinued: boolean;
}

class PrintfulAPI {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.PRINTFUL_API_KEY || '';
    this.baseUrl = process.env.PRINTFUL_BASE_URL || 'https://api.printful.com';
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Printful API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return data.result;
  }

  // Get all store products (your custom products)
  async getStoreProducts(): Promise<PrintfulProduct[]> {
    return this.makeRequest('/store/products');
  }

  // Get catalog products (available for customization)
  async getCatalogProducts(): Promise<PrintfulCatalogProduct[]> {
    return this.makeRequest('/products');
  }

  // Get specific product details
  async getProduct(productId: number): Promise<PrintfulCatalogProduct> {
    return this.makeRequest(`/products/${productId}`);
  }

  // Get product variants
  async getProductVariants(productId: number) {
    return this.makeRequest(`/products/${productId}`);
  }

  // Create a new store product
  async createStoreProduct(productData: any) {
    return this.makeRequest('/store/products', {
      method: 'POST',
      body: JSON.stringify(productData),
    });
  }

  // Get shipping rates
  async getShippingRates(recipient: any, items: any[]) {
    return this.makeRequest('/shipping/rates', {
      method: 'POST',
      body: JSON.stringify({ recipient, items }),
    });
  }

  // Create order
  async createOrder(orderData: any) {
    return this.makeRequest('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }
}

export const printfulAPI = new PrintfulAPI();
export type { PrintfulProduct, PrintfulVariant, PrintfulCatalogProduct };
```

---

## 📦 PHASE 4: FETCH REAL PRODUCTS

### **Step 4.1: Create Product Sync Service**

```typescript
// src/lib/printful-sync.ts
import { printfulAPI } from './printful-api';
import { RealProduct } from './real-products';

interface PrintfulToVienoraMapping {
  printfulId: number;
  name: string;
  category: string;
  basePrice: number;
  luxuryMarkup: number;
  vienoraPrice: number;
  description: string;
  images: string[];
  features: string[];
}

class PrintfulSync {
  private readonly LUXURY_MARKUP = 2.5; // 150% markup for luxury positioning
  private readonly CATEGORY_MAPPING = {
    // Apparel
    71: 'Luxury Apparel', // T-shirts
    18: 'Luxury Apparel', // Hoodies
    24: 'Luxury Apparel', // Tank tops
    420: 'Luxury Apparel', // Long sleeve

    // Accessories
    26: 'Luxury Accessories', // Bags
    172: 'Luxury Accessories', // Backpacks
    194: 'Luxury Accessories', // Fanny packs

    // Home & Living
    19: 'Luxury Home', // Mugs
    26: 'Luxury Home', // Posters
    173: 'Luxury Home', // Canvas prints
    37: 'Luxury Home', // Pillows

    // Tech Accessories
    242: 'Tech Accessories', // Phone cases
    390: 'Tech Accessories', // Laptop sleeves
  };

  async fetchAndTransformProducts(): Promise<RealProduct[]> {
    try {
      console.log('🔄 Fetching products from Printful...');

      // Get catalog products (available for customization)
      const catalogProducts = await printfulAPI.getCatalogProducts();

      // Filter for luxury-appropriate products
      const luxuryProducts = catalogProducts.filter(product =>
        !product.is_discontinued &&
        parseFloat(product.retail_price) >= 15 && // Minimum price threshold
        this.isLuxuryCategory(product.id)
      );

      console.log(`📦 Found ${luxuryProducts.length} luxury-appropriate products`);

      // Transform to Vienora format
      const vienoraProducts = await Promise.all(
        luxuryProducts.slice(0, 20).map(product => this.transformToVienoraProduct(product))
      );

      console.log(`✅ Transformed ${vienoraProducts.length} products for Vienora`);
      return vienoraProducts;

    } catch (error) {
      console.error('❌ Error fetching Printful products:', error);
      throw new Error('Failed to sync products from Printful');
    }
  }

  private isLuxuryCategory(productId: number): boolean {
    return Object.keys(this.CATEGORY_MAPPING).includes(productId.toString());
  }

  private async transformToVienoraProduct(printfulProduct: any): Promise<RealProduct> {
    const basePrice = parseFloat(printfulProduct.retail_price);
    const vienoraPrice = Math.round(basePrice * this.LUXURY_MARKUP);
    const originalPrice = Math.round(vienoraPrice * 1.2); // Show 20% "discount"

    return {
      id: `printful_${printfulProduct.id}`,
      spocketId: undefined,
      aliexpressId: undefined,
      name: this.enhanceName(printfulProduct.title),
      description: this.createLuxuryDescription(printfulProduct),
      price: vienoraPrice,
      originalPrice: originalPrice,
      discountPercentage: Math.round(((originalPrice - vienoraPrice) / originalPrice) * 100),
      images: [printfulProduct.image],
      category: this.CATEGORY_MAPPING[printfulProduct.id] || 'Luxury Accessories',
      rating: this.generateRating(),
      reviewCount: this.generateReviewCount(vienoraPrice),
      features: this.extractFeatures(printfulProduct),
      specifications: this.generateSpecs(printfulProduct),
      supplier: {
        name: 'Printful Premium',
        location: 'United States',
        rating: 4.9,
        processingTime: '2-4 business days',
        shippingMethods: ['Express', 'Standard'],
        performanceScore: 95
      },
      inventory: {
        inStock: true,
        quantity: 999, // Printful handles inventory
        lowStockThreshold: 10
      },
      shipping: {
        freeShipping: vienoraPrice >= 75,
        estimatedDays: '3-7 business days',
        methods: [
          { name: 'Standard Shipping', price: vienoraPrice >= 75 ? 0 : 9.99, duration: '5-7 days' },
          { name: 'Express Shipping', price: 19.99, duration: '3-4 days' }
        ]
      },
      luxury: {
        isLuxury: true,
        qualityScore: this.calculateLuxuryScore(printfulProduct, vienoraPrice),
        qualityTier: this.assignQualityTier(vienoraPrice),
        luxuryFeatures: this.generateLuxuryFeatures(printfulProduct),
        isLimitedEdition: false,
        isHandcrafted: true,
        provenance: 'Printful Certified'
      },
      seo: {
        slug: this.generateSlug(printfulProduct.title),
        metaTitle: `${this.enhanceName(printfulProduct.title)} - Vienora Luxury Collection`,
        metaDescription: `Discover premium ${printfulProduct.title} in our exclusive luxury collection. Custom designed, premium materials, fast shipping.`,
        keywords: this.generateKeywords(printfulProduct)
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  private enhanceName(originalName: string): string {
    const enhancements = {
      'T-Shirt': 'Premium Custom T-Shirt',
      'Hoodie': 'Luxury Custom Hoodie',
      'Mug': 'Artisan Custom Mug',
      'Poster': 'Premium Art Print',
      'Pillow': 'Luxury Custom Pillow',
      'Phone Case': 'Premium Custom Phone Case',
      'Tote Bag': 'Luxury Custom Tote Bag'
    };

    let enhanced = originalName;
    for (const [key, value] of Object.entries(enhancements)) {
      if (originalName.includes(key)) {
        enhanced = originalName.replace(key, value);
        break;
      }
    }

    return `Vienora ${enhanced}`;
  }

  private createLuxuryDescription(product: any): string {
    return `${product.description || 'Premium custom product crafted with attention to detail.'}

✨ **Vienora Luxury Collection**
🎨 **Custom Design Options Available**
🏭 **Premium Manufacturing Standards**
📦 **Luxury Packaging Included**
🚚 **Fast & Reliable Shipping**
🔒 **Quality Guarantee**

Transform your style with this exclusive piece from our curated luxury collection. Each item is made-to-order with premium materials and meticulous attention to detail.

*Part of the exclusive Vienora lifestyle collection - where luxury meets personalization.*`;
  }

  private calculateLuxuryScore(product: any, price: number): number {
    let score = 70; // Base luxury score

    // Price factor (higher price = more luxury appeal)
    if (price >= 100) score += 15;
    else if (price >= 50) score += 10;
    else if (price >= 25) score += 5;

    // Product type factor
    const luxuryTypes = ['Hoodie', 'Pillow', 'Canvas', 'Poster'];
    if (luxuryTypes.some(type => product.title.includes(type))) score += 10;

    // Customization factor
    if (product.files && product.files.length > 0) score += 10;

    return Math.min(score, 100);
  }

  private assignQualityTier(price: number): 'Premium' | 'Luxury' | 'Ultra-Luxury' {
    if (price >= 100) return 'Ultra-Luxury';
    if (price >= 50) return 'Luxury';
    return 'Premium';
  }

  private generateLuxuryFeatures(product: any): string[] {
    const features = ['Custom Design', 'Premium Materials', 'Vienora Exclusive'];

    if (product.brand) features.push('Brand Quality');
    if (product.files && product.files.length > 0) features.push('Personalization Available');

    return features;
  }

  private extractFeatures(product: any): string[] {
    const features = ['Premium Quality', 'Custom Design Options', 'Fast Shipping'];

    if (product.description) {
      if (product.description.includes('cotton')) features.push('Premium Cotton');
      if (product.description.includes('organic')) features.push('Organic Materials');
      if (product.description.includes('sustainable')) features.push('Eco-Friendly');
    }

    return features;
  }

  private generateSpecs(product: any): Record<string, string> {
    return {
      'Material': 'Premium Quality',
      'Customization': 'Available',
      'Production': '2-4 business days',
      'Shipping': 'Worldwide',
      'Quality': 'Guaranteed'
    };
  }

  private generateRating(): number {
    return 4.6 + Math.random() * 0.4; // 4.6 to 5.0
  }

  private generateReviewCount(price: number): number {
    const baseCount = Math.floor(Math.random() * 100) + 50;
    const priceMultiplier = price > 75 ? 0.7 : 1; // Luxury items have fewer but higher quality reviews
    return Math.floor(baseCount * priceMultiplier);
  }

  private generateSlug(title: string): string {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  private generateKeywords(product: any): string[] {
    const keywords = ['luxury', 'custom', 'premium', 'vienora'];

    if (product.title) {
      const titleWords = product.title.toLowerCase().split(' ');
      keywords.push(...titleWords.filter(word => word.length > 3));
    }

    return [...new Set(keywords)].slice(0, 10);
  }
}

export const printfulSync = new PrintfulSync();
```

---

## 🔄 PHASE 5: UPDATE PRODUCT API

### **Step 5.1: Modify Product API Route**

```typescript
// src/app/api/products/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { printfulSync } from '@/lib/printful-sync';
import { getCuratedProducts } from '@/lib/real-products';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const source = searchParams.get('source') || 'auto';
    const category = searchParams.get('category');
    const limit = parseInt(searchParams.get('limit') || '20');

    console.log('📦 Product API called with source:', source);

    let products = [];

    if (source === 'printful' || source === 'auto') {
      try {
        // Try to get real Printful products
        console.log('🔄 Fetching real Printful products...');
        const printfulProducts = await printfulSync.fetchAndTransformProducts();

        if (printfulProducts.length > 0) {
          products = printfulProducts;
          console.log(`✅ Using ${products.length} real Printful products`);

          return NextResponse.json({
            success: true,
            source: 'printful',
            products: products.slice(0, limit),
            total: products.length,
            message: 'Real Printful products loaded successfully'
          });
        }
      } catch (error) {
        console.error('❌ Printful API error:', error);
      }
    }

    // Fallback to existing curated products
    console.log('📦 Falling back to curated demo products...');
    products = await getCuratedProducts(category, limit);

    return NextResponse.json({
      success: true,
      source: 'demo',
      products: products,
      total: products.length,
      message: 'Demo products loaded (configure Printful API for real products)'
    });

  } catch (error) {
    console.error('❌ Product API error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to load products' },
      { status: 500 }
    );
  }
}
```

---

## 🎯 PHASE 6: TEST THE INTEGRATION

### **Step 6.1: Create Test Route**

```typescript
// src/app/api/printful/test/route.ts
import { NextResponse } from 'next/server';
import { printfulAPI } from '@/lib/printful-api';
import { printfulSync } from '@/lib/printful-sync';

export async function GET() {
  try {
    console.log('🧪 Testing Printful connection...');

    // Test 1: Check API connection
    const catalogProducts = await printfulAPI.getCatalogProducts();
    console.log(`✅ Catalog products: ${catalogProducts.length}`);

    // Test 2: Get transformed products
    const vienoraProducts = await printfulSync.fetchAndTransformProducts();
    console.log(`✅ Vienora products: ${vienoraProducts.length}`);

    // Test 3: Sample product data
    const sampleProduct = vienoraProducts[0];

    return NextResponse.json({
      success: true,
      message: 'Printful integration working!',
      data: {
        catalogProducts: catalogProducts.length,
        vienoraProducts: vienoraProducts.length,
        sampleProduct: sampleProduct,
        apiStatus: 'Connected'
      }
    });

  } catch (error) {
    console.error('❌ Printful test failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      message: 'Printful integration failed - check API credentials'
    }, { status: 500 });
  }
}
```

---

## 🚀 PHASE 7: DEPLOY AND TEST

### **Step 7.1: Quick Setup Checklist**

```bash
# 1. Add environment variables to .env.local
echo "PRINTFUL_API_KEY=your_api_key_here" >> .env.local

# 2. Install dependencies
bun install

# 3. Start development server
bun dev

# 4. Test the integration
curl http://localhost:3000/api/printful/test

# 5. Test product API with real data
curl http://localhost:3000/api/products?source=printful&limit=5
```

### **Step 7.2: Verify Integration**

1. **Open**: http://localhost:3000/api/printful/test
2. **Check**: Should return success with real product count
3. **Open**: http://localhost:3000/api/products?source=printful
4. **Verify**: Real Printful products with Vienora pricing
5. **Visit**: http://localhost:3000/shop
6. **Confirm**: Real products appear instead of placeholders

---

## 💎 REAL PRODUCT EXAMPLES

### **What You'll Get (Sample Products):**

```json
{
  "name": "Vienora Premium Custom T-Shirt",
  "price": 47,
  "originalPrice": 56,
  "category": "Luxury Apparel",
  "supplier": "Printful Premium",
  "luxury": {
    "qualityScore": 85,
    "qualityTier": "Luxury",
    "luxuryFeatures": ["Custom Design", "Premium Materials", "Vienora Exclusive"]
  },
  "features": ["Premium Cotton", "Custom Design Options", "Fast Shipping"],
  "shipping": {
    "freeShipping": false,
    "methods": [
      {"name": "Standard", "price": 9.99, "duration": "5-7 days"},
      {"name": "Express", "price": 19.99, "duration": "3-4 days"}
    ]
  }
}
```

---

## 🎯 SUCCESS VALIDATION

### **✅ Integration Complete When:**

1. **API Test Returns Success**: /api/printful/test shows connected
2. **Real Products Load**: /api/products shows Printful products
3. **Shop Page Works**: Real products display with luxury pricing
4. **No Placeholder Data**: All demo products replaced with real ones
5. **Prices Make Sense**: Luxury markup applied (2.5x base price)
6. **Luxury Features**: Quality tiers and features assigned correctly

---

## 🔥 IMMEDIATE NEXT STEPS

1. **Get Printful API Key** (5 minutes)
2. **Add to Environment Variables** (2 minutes)
3. **Deploy the Code Above** (15 minutes)
4. **Test Integration** (5 minutes)
5. **Verify Real Products** (5 minutes)

**Total Time: 30 minutes to real luxury products!**

---

## 📞 SUPPORT

**If you get stuck:**
- **Printful API Docs**: https://developers.printful.com/
- **API Support**: developers@printful.com
- **Check API Key**: Make sure it's correct in .env.local

**Ready to replace those placeholders with REAL luxury products? Let's do this!** 🚀💎
